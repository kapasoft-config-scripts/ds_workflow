<div class="col-sm-12">
    <h3>Recent Work</h3>
</div>
<div class="module col-sm-3">
    <a href="portfolio-single.html"><img src="<?php print base_path().drupal_get_path('module', DS_TARGET_MODULE) . '/assets/' ?>img/birdgreen-lg.jpg" alt="Placeholder" class="thumbnail img-responsive"></a>
    <h3><a href="portfolio-single.html">Hummingbird Project</a></h3>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua.</p>
</div>
<div class="module col-sm-3">
    <a href="portfolio-single.html"><img src="<?php print base_path().drupal_get_path('module', DS_TARGET_MODULE) . '/assets/' ?>img/flowers-lg.jpg" alt="Placeholder" class="thumbnail img-responsive"></a>
    <h3><a href="portfolio-single.html">Red Flowers Project</a></h3>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua.</p>
</div>
<div class="module col-sm-3">
    <a href="portfolio-single.html"><img src="<?php print base_path().drupal_get_path('module', DS_TARGET_MODULE) . '/assets/' ?>img/leaves-lg.jpg" alt="Placeholder" class="thumbnail"></a>
    <h3><a href="portfolio-single.html">Leaves Project</a></h3>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua.</p>
</div>
<div class="module col-sm-3">
    <a href="portfolio-single.html"><img src="<?php print base_path().drupal_get_path('module', DS_TARGET_MODULE) . '/assets/' ?>img/snail-lg.jpg" alt="Placeholder" class="thumbnail"></a>
    <h3><a href="portfolio-single.html">Snail Project</a></h3>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
        tempor incididunt ut labore et dolore magna aliqua.</p>
</div>