<div class="" style="<?php print $slider_tapi["style"]; ?>">
    <div class="<?php print $slider_tapi['outer']; ?>">
        <div class="<?php print $slider_tapi['inner']; ?>">
            <ul>
                <?php
                //                foreach($frames as $key => $frame){
                //                    print '<li data-transition="'.$frame['data-transition'].'" data-slotamount="'.$frame['data-slotamount'].'" data-masterspeed="'.$frame['data-masterspeed'].'" >';
                //                    print '<img src="'.$frame['bg-img'].'" >';
                //
                //                    foreach($frame['elements'] as $key => $element){
                //                        print '<div class="'.$element['class'].'"';
                //                        print 'data-x="'.$element['data-x'].'"';
                //                        print 'data-y="'.$element['data-y'].'"';
                //                        print 'data-speed="'.$element['data-speed'].'"';
                //                        print 'data-start="'.$element['data-start'].'"';
                //                        print 'data-easing="'.$element['data-easing'].'"  >';
                //                        print $element['content'];
                //                        print '</div>';
                //                    }
                //
                //                    print '</li>';
                //                }
                ?>
                <li data-transition="random" data-slotamount="7" data-masterspeed="300">

                    <img src="sites/default/files/designssquare_com_theme_builder/images/gallery/retro_stripe1.png">

                    <div class="tp-caption lfb"
                         data-x="460"
                         data-y="16"
                         data-speed="1500"
                         data-start="500"
                         data-easing="easeInOutElastic"><img
                            src="sites/default/files/designssquare_com_theme_builder/images/gallery/ipad1.png"
                            alt="Image 1"></div>

                    <div class="tp-caption lfb"
                         data-x="346"
                         data-y="120"
                         data-speed="1500"
                         data-start="1000"
                         data-easing="easeInOutElastic"><img
                            src="sites/default/files/designssquare_com_theme_builder/images/gallery/ipad21.png"
                            alt="Image 2"></div>

                    <div class="tp-caption very_large_text lfl"
                         data-x="-150"
                         data-y="42"
                         data-speed="1500"
                         data-start="1500"
                         data-easing="easeInOutElastic">Builder is awesome
                    </div>

                    <div class="tp-caption big_white lfl"
                         data-x="-144"
                         data-y="104"
                         data-speed="1500"
                         data-start="2500"
                         data-easing="easeOutElastic">HTML TEMPLATE
                    </div>

                    <div class="tp-caption small_text sfb"
                         data-x="-140"
                         data-y="186"
                         data-speed="1500"
                         data-start="3500"
                         data-easing="easeOutExpo">Powerful HTML template designed in a clean and minimalistic
                        style.<br>This
                        template is very flexible, easy for customizing and well documented, <br>approaches for personal
                        and
                        professional use.
                    </div>
                </li>
                <li data-transition="random" data-slotamount="7" data-masterspeed="300">
                    <img src="sites/default/files/designssquare_com_theme_builder/images/gallery/retro_stripe1.png">

                    <div class="tp-caption lfl"
                         data-x="-45"
                         data-y="0"
                         data-speed="2500"
                         data-start="1000"
                         data-easing="easeOutElastic"><img
                            src="sites/default/files/designssquare_com_theme_builder/images/gallery/box-blur.png"
                            alt="Image 6"></div>

                    <div class="tp-caption lfl"
                         data-x="-308"
                         data-y="7"
                         data-speed="2500"
                         data-start="500"
                         data-easing="easeInOutElastic"><img
                            src="sites/default/files/designssquare_com_theme_builder/images/gallery/box-normal.png"
                            alt="Image 7"></div>

                    <div class="tp-caption very_large_text fade"
                         data-x="350"
                         data-y="32"
                         data-speed="300"
                         data-start="1300"
                         data-easing="easeOutExpo">Powerfull & Responsive
                    </div>

                    <div class="tp-caption big_white fade"
                         data-x="350"
                         data-y="95"
                         data-speed="300"
                         data-start="1600"
                         data-easing="easeOutExpo">HTML TEMPLATE
                    </div>

                    <div class="tp-caption small_text fade"
                         data-x="350"
                         data-y="167"
                         data-speed="300"
                         data-start="1900"
                         data-easing="easeOutExpo">
                        - BOOTSTRAP UNDER THE HOOD<br>
                        - INTEGRATED REVOLUTION SLIDER (15$ VALUE )<br>
                        - UNLIMITED COLORS<br>
                        - MORE 40 HTML PAGES<br>
                        - FRIENDLY HTML/CSS CODE
                    </div>

                    <div class="tp-caption fade"
                         data-x="350"
                         data-y="298"
                         data-speed="300"
                         data-start="2200"
                         data-easing="easeOutExpo">
                        <a href='javascript:alert("click");' class='tp-button darkgrey small'>Purchase now!</a></div>

                    <div class="tp-caption fade"
                         data-x="670"
                         data-y="81"
                         data-speed="300"
                         data-start="2500"
                         data-easing="easeOutExpo">
                        <img src="sites/default/files/designssquare_com_theme_builder/images/gallery/45.png"
                             alt="Image 7"></div>
                </li>
                <li data-transition="random" data-slotamount="7" data-masterspeed="300">
                    <img src="sites/default/files/designssquare_com_theme_builder/images/gallery/retro_stripe1.png">

                    <div class="tp-caption fade"
                         data-x="0"
                         data-y="19"
                         data-speed="300"
                         data-start="500"
                         data-easing="easeOutExpo"><img
                            src="sites/default/files/designssquare_com_theme_builder/images/gallery/hand-black2.png"
                            alt="Image 2"></div>

                    <div class="tp-caption fade"
                         data-x="196"
                         data-y="70"
                         data-speed="300"
                         data-start="800"
                         data-easing="easeOutExpo">
                        <iframe src='http://player.vimeo.com/video/34134308?title=0&amp;byline=0&amp;portrait=0'
                                width='420'
                                height='314' style='width:420px;height:314px;'></iframe>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div>
<span style="clear: both"></span>