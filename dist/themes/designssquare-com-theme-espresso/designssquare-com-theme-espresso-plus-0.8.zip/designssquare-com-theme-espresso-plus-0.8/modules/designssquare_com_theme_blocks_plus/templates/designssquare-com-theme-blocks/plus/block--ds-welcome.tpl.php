<div class="span4 hidden-phone column_container">
    <div class="row-fluid">
        <div class="span12">

            <div style="background-color: rgb(58, 58, 58); padding: 10px; margin-bottom: 20px;">
                <h1 style="color: rgb(255, 255, 255) !important; margin-bottom: 3px !important;"><b>WELCOME!</b></h1>
                <h5 style="color: rgb(255, 255, 255);">Your most important message or cacthy phrase goes here and also it goes right here.</h5>
            </div>

            <p>Simple and flexible HTML, CSS, and Javascript for popular user interface components and interactions</p>
            <p>
                <span class="pun"><em>Builder is designed to help people of all skill levels designer or developer, huge nerd or early beginner. Use it as a complete kit or use to start something more complex</em></span>
            </p>

            <hr class="visible-desktop"></hr>
            <h4 class="visible-desktop">Some of Template Features:</h4>

            <div class="visible-desktop">
                <div class="span6">
                    <ul class="unstyled" style="margin-top: 10px;">
                        <li><em class="icon-user"></em>Built for and by nerds</li>
                        <li><em class="icon-th"></em>12-column grid</li>
                        <li><em class="icon-resize-horizontal"></em>Max-width 1200px</li>
                        <li><em class="icon-book"></em>Growing library</li>
                    </ul>
                </div>

                <div class="span6">
                    <ul class="unstyled" style="margin-top: 10px;">
                        <li><em class="icon-resize-small"></em>Responsive design</li>
                        <li><em class="icon-eye-open"></em>Cross-everything</li>
                        <li><em class="icon-list-alt"></em>Styleguide docs</li>
                        <li><em class="icon-cog"></em>jQuery plugins</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>