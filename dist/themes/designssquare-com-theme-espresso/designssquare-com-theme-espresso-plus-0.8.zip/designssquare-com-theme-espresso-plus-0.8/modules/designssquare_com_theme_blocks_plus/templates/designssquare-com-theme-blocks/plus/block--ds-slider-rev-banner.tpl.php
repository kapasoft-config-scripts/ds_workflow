<div class="" style="<?php print $slider_tapi["style"]; ?>">
    <div class="<?php print $slider_tapi['outer']; ?>">
        <div class="<?php print $slider_tapi['inner']; ?>">
            <ul>
                <li data-transition="random" data-slotamount="7" data-masterspeed="300" >

                    <img src="sites/default/files/designssquare_com_theme_builder/images/gallery/Anchor_v1_preview2-880x461.png" >

                    <div class="tp-caption big_white fade"
                         data-x="507"
                         data-y="90"
                         data-speed="300"
                         data-start="500"
                         data-easing="easeOutExpo">
                        <div>DRUPAL THEME</div>
                    </div>


                    <div class="tp-caption very_large_text fade"
                         data-x="224"
                         data-y="24"
                         data-speed="300"
                         data-start="500"
                         data-easing="easeOutExpo">
                        <div>Builder is awesome</div>
                    </div>
                </li>

                <li data-transition="random" data-slotamount="7" data-masterspeed="300" >
                    <img src="sites/default/files/designssquare_com_theme_builder/images/gallery/1.jpg" >

                    <div class="tp-caption fade"
                         data-x="41"
                         data-y="28"
                         data-speed="300"
                         data-start="800"
                         data-easing="easeOutExpo">
                        <img src="sites/default/files/designssquare_com_theme_builder/images/gallery/ipad1.png" alt="Image 1"></div>

                    <div class="tp-caption fade"
                         data-x="256"
                         data-y="90"
                         data-speed="300"
                         data-start="1100"
                         data-easing="easeOutExpo">
                        <img src="sites/default/files/designssquare_com_theme_builder/images/gallery/ipad21.png" alt="Image 3"></div>
                </li>

                <!--<li data-transition="random" data-slotamount="7" data-masterspeed="300" >-->
                <!--<img src="sites/default/files/designssquare_com_theme_builder/images/gallery/blur.jpg" >-->
                <!---->
                <!--<div class="tp-caption fade"  -->
                <!--data-x="-12" -->
                <!--data-y="8" -->
                <!--data-speed="300" -->
                <!--data-start="500" -->
                <!--data-easing="easeOutExpo">-->
                <!--<img src="sites/default/files/designssquare_com_theme_builder/images/gallery/hand-black2.png" alt="Image 1"></div>-->
                <!---->
                <!--<div class="tp-caption fade"  -->
                <!--data-x="184" -->
                <!--data-y="59" -->
                <!--data-speed="300" -->
                <!--data-start="800" -->
                <!--data-easing="easeOutExpo">-->
                <!--<iframe src='http://player.vimeo.com/video/34134308?title=0&amp;byline=0&amp;portrait=0' width='420' height='314' style='width:420px;height:314px;'></iframe>-->
                <!--</div>-->
                <!--</li>-->
            </ul>
        </div>
    </div>
</div>
<span style="clear: both"></span>