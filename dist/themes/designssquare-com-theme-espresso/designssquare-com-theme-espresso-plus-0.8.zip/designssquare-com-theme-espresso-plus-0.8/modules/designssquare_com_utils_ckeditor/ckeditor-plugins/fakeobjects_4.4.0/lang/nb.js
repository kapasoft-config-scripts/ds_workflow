﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'nb', {
	anchor: 'Anker',
	flash: 'Flash-animasjon',
	hiddenfield: 'Skjult felt',
	iframe: 'IFrame',
	unknown: 'Ukjent objekt'
} );
