﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'bg', {
	alt: 'Алтернативен текст',
	btnUpload: 'Изпрати я на сървъра',
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'Инфо за снимка',
	lockRatio: 'Заключване на съотношението',
	menu: 'Настройки за снимка',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Нулиране на размер',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Настройки за снимка',
	uploadTab: 'Качване',
	urlMissing: 'Image source URL is missing.' // MISSING
} );
