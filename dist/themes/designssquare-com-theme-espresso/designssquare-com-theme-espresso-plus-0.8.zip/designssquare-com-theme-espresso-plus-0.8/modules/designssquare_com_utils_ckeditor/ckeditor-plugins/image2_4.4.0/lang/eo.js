﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'eo', {
	alt: 'Anstataŭiga Teksto',
	btnUpload: 'Sendu al Servilo',
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'Informoj pri Bildo',
	lockRatio: 'Konservi Proporcion',
	menu: 'Atributoj de Bildo',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'Origina Grando',
	resizer: 'Click and drag to resize', // MISSING
	title: 'Atributoj de Bildo',
	uploadTab: 'Alŝuti',
	urlMissing: 'La fontretadreso de la bildo mankas.'
} );
