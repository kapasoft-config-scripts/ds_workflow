﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'gu', {
	alt: 'ઑલ્ટર્નટ ટેક્સ્ટ',
	btnUpload: 'આ સર્વરને મોકલવું',
	captioned: 'Captioned image', // MISSING
	captionPlaceholder: 'Caption', // MISSING
	infoTab: 'ચિત્ર ની જાણકારી',
	lockRatio: 'લૉક ગુણોત્તર',
	menu: 'ચિત્રના ગુણ',
	pathName: 'image', // MISSING
	pathNameCaption: 'caption', // MISSING
	resetSize: 'રીસેટ સાઇઝ',
	resizer: 'Click and drag to resize', // MISSING
	title: 'ચિત્રના ગુણ',
	uploadTab: 'અપલોડ',
	urlMissing: 'ઈમેજની મૂળ URL છે નહી.'
} );
