﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'xmas', 'da', {
	title: 'Jul',
	signature: 'Den CKEditor Team',
	wishes: '<p>Vi ønsker alle</p>' +
			'<p class="big">en Glædelig Jul</p>' +
			'<p class="big">og</p>' +
			'<p class="big">et Godt Nytår!</p>'
} );
