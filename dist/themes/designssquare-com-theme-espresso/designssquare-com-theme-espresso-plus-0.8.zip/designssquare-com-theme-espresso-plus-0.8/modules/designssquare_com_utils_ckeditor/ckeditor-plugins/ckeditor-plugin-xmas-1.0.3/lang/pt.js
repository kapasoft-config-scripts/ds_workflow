﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'xmas', 'pt', {
	title: 'Natal!',
	signature: 'O time do CKEditor',
	wishes: '<p>Desejamos um</p>' +
			'<p class="big">Feliz Natal!</p>' +
			'<p class="big">e</p>' +
			'<p class="big">Ótimo Ano Novo!</p>'
} );
