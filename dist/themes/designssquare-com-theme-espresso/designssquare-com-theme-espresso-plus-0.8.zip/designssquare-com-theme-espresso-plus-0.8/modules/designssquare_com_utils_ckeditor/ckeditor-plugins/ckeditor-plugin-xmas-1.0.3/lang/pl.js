﻿/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'xmas', 'pl', {
	title: 'Święta',
	signature: 'Zespół CKEditor',
	wishes: '<p style="margin-top:40px;" class="big">Wesołych Świąt!</p>' +
			'<p class="big">Życzy $1</p>'

} );
