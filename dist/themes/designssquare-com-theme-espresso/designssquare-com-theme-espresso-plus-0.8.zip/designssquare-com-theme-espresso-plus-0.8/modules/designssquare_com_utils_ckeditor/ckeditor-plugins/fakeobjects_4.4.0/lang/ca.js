﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'fakeobjects', 'ca', {
	anchor: 'Àncora',
	flash: 'Animació Flash',
	hiddenfield: 'Camp ocult',
	iframe: 'IFrame',
	unknown: 'Objecte desconegut'
} );
